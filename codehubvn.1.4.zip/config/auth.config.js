module.exports = {
    secret: "codehubvn-secret-key",
    user: "vncodehub@gmail.com",
    pass: "Codehubvn_1",
};